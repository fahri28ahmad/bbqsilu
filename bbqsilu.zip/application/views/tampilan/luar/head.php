<!DOCTYPE html>
<html lang="en">
  <head>
    <title>SILU</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet"> -->

    <link rel="stylesheet" href="<?php echo base_url();?>public/as/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>public/as/css/animate.css">
    
    <link rel="stylesheet" href="<?php echo base_url();?>public/as/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>public/as/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>public/as/css/magnific-popup.css">

    <link rel="stylesheet" href="<?php echo base_url();?>public/as/css/aos.css">

    <link rel="stylesheet" href="<?php echo base_url();?>public/as/css/ionicons.min.css">

    <link rel="stylesheet" href="<?php echo base_url();?>public/as/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="<?php echo base_url();?>public/as/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="<?php echo base_url();?>public/as/css/flaticon.css">
    <link rel="stylesheet" href="<?php echo base_url();?>public/as/css/icomoon.css">
    <link rel="stylesheet" href="<?php echo base_url();?>public/as/css/style.css">
  </head>